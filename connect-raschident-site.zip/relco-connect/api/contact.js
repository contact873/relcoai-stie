'use strict';

/**
 * POST /api/contact
 * Receives the website contact form and emails it to CONTACT_TO
 * (default: contact@raschident.com).
 *
 * Delivery options (first one configured wins):
 *   1. Resend  -> set RESEND_API_KEY
 *   2. SMTP    -> set SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS
 *
 * Optional env vars:
 *   CONTACT_TO   where enquiries are delivered   (default contact@raschident.com)
 *   MAIL_FROM    sender shown on the email       (default "Connect Website <forms@raschident.com>")
 *   AUTO_REPLY   set to "false" to disable the confirmation email to the visitor
 */

const TO = process.env.CONTACT_TO || 'contact@raschident.com';
const FROM = process.env.MAIL_FROM || 'Connect Website <forms@raschident.com>';

const TOPICS = {
  audit: 'Free growth audit',
  quote: 'Quote request',
  order: 'Order enquiry',
  team: 'Dedicated team enquiry',
  general: 'General enquiry'
};

// Best-effort rate limit (per warm serverless instance).
const hits = new Map();
const WINDOW_MS = 10 * 60 * 1000;
const MAX_HITS = 5;

function limited(ip) {
  const now = Date.now();
  const list = (hits.get(ip) || []).filter((t) => now - t < WINDOW_MS);
  list.push(now);
  hits.set(ip, list);
  if (hits.size > 500) {
    for (const [k, v] of hits) if (!v.some((t) => now - t < WINDOW_MS)) hits.delete(k);
  }
  return list.length > MAX_HITS;
}

const esc = (s) =>
  String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

// Strip CR/LF so visitor input can never inject email headers.
const oneLine = (s, max) => String(s || '').replace(/[\r\n\t]+/g, ' ').trim().slice(0, max);
const multiLine = (s, max) => String(s || '').replace(/\r\n/g, '\n').trim().slice(0, max);

function clean(body) {
  const b = body || {};
  return {
    name: oneLine(b.name, 120),
    email: oneLine(b.email, 200),
    company: oneLine(b.company, 160),
    phone: oneLine(b.phone, 40),
    siteUrl: oneLine(b.site_url, 200),
    topic: TOPICS[b.topic] ? b.topic : 'general',
    service: oneLine(b.service, 60),
    budget: oneLine(b.budget, 60),
    message: multiLine(b.message, 5000),
    page: oneLine(b.page, 300),
    honeypot: String(b.website || ''),
    elapsed: Number(b.elapsed) || 0
  };
}

function validate(d) {
  if (d.name.length < 2) return 'Enter your name.';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(d.email)) return 'Enter a valid email address.';
  if (d.message.length < 10) return 'Tell us a little more in the message.';
  return null;
}

function buildEmail(d, meta) {
  const label = TOPICS[d.topic];
  const rows = [
    ['Enquiry type', label],
    ['Name', d.name],
    ['Email', d.email],
    ['Company', d.company],
    ['Phone / WhatsApp', d.phone],
    ['Website', d.siteUrl],
    ['Service of interest', d.service],
    ['Budget', d.budget]
  ].filter((r) => r[1]);

  const text =
    `New website enquiry: ${label}\n\n` +
    rows.map((r) => `${r[0]}: ${r[1]}`).join('\n') +
    `\n\nMessage:\n${d.message}\n\n---\nSent from: ${d.page || 'contact form'}\nIP: ${meta.ip}\nTime: ${meta.time}\n` +
    `Reply directly to this email to answer ${d.name}.`;

  const html =
    `<div style="font-family:Arial,Helvetica,sans-serif;font-size:15px;color:#1b1f27;max-width:640px">` +
    `<h2 style="margin:0 0 16px;font-size:20px">New website enquiry: ${esc(label)}</h2>` +
    `<table style="border-collapse:collapse;width:100%">` +
    rows
      .map(
        (r) =>
          `<tr><td style="padding:6px 12px 6px 0;color:#667085;white-space:nowrap;vertical-align:top">${esc(r[0])}</td>` +
          `<td style="padding:6px 0">${esc(r[1])}</td></tr>`
      )
      .join('') +
    `</table>` +
    `<h3 style="margin:22px 0 8px;font-size:16px">Message</h3>` +
    `<div style="white-space:pre-wrap;border-left:3px solid #c9a45c;padding:4px 0 4px 14px">${esc(d.message)}</div>` +
    `<p style="margin-top:24px;color:#667085;font-size:13px">Sent from ${esc(d.page || 'contact form')} &middot; IP ${esc(meta.ip)} &middot; ${esc(meta.time)}<br>` +
    `Reply to this email to answer ${esc(d.name)} directly.</p></div>`;

  return { subject: `[Connect] ${label} from ${d.name}`, text, html };
}

function buildReceipt(d) {
  const label = TOPICS[d.topic].toLowerCase();
  const text =
    `Hello ${d.name},\n\n` +
    `Thank you for getting in touch. We have received your ${label} and a person will reply within one working day.\n\n` +
    `A copy of your message:\n\n${d.message}\n\n` +
    `If anything is urgent, message us on WhatsApp: https://wa.me/923237989871\n\n` +
    `Connect by Relco Digital\nhttps://connect.raschident.com`;
  const html =
    `<div style="font-family:Arial,Helvetica,sans-serif;font-size:15px;color:#1b1f27;max-width:600px">` +
    `<p>Hello ${esc(d.name)},</p>` +
    `<p>Thank you for getting in touch. We have received your ${esc(label)} and a person will reply within one working day.</p>` +
    `<p style="color:#667085;margin-bottom:6px">A copy of your message:</p>` +
    `<div style="white-space:pre-wrap;border-left:3px solid #c9a45c;padding:4px 0 4px 14px">${esc(d.message)}</div>` +
    `<p style="margin-top:20px">If anything is urgent, message us on <a href="https://wa.me/923237989871">WhatsApp</a>.</p>` +
    `<p>Connect by Relco Digital<br><a href="https://connect.raschident.com">connect.raschident.com</a></p></div>`;
  return { subject: 'We received your message | Connect by Relco Digital', text, html };
}

async function sendViaResend(msg) {
  const res = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${process.env.RESEND_API_KEY}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      from: FROM,
      to: [msg.to],
      reply_to: msg.replyTo,
      subject: msg.subject,
      html: msg.html,
      text: msg.text
    })
  });
  if (!res.ok) {
    const detail = await res.text().catch(() => '');
    throw new Error(`Resend ${res.status}: ${detail.slice(0, 300)}`);
  }
}

let transporter;
async function sendViaSmtp(msg) {
  if (!transporter) {
    const nodemailer = require('nodemailer');
    const port = Number(process.env.SMTP_PORT || 465);
    transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port,
      secure: port === 465,
      auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
    });
  }
  await transporter.sendMail({
    from: process.env.SMTP_FROM || FROM,
    to: msg.to,
    replyTo: msg.replyTo,
    subject: msg.subject,
    text: msg.text,
    html: msg.html
  });
}

function provider() {
  if (process.env.RESEND_API_KEY) return sendViaResend;
  if (process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS) return sendViaSmtp;
  return null;
}

module.exports = async function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store');

  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ ok: false, error: 'Method not allowed.' });
  }

  let body = req.body;
  if (typeof body === 'string') {
    try { body = JSON.parse(body); } catch (e) { body = null; }
  }
  if (!body || typeof body !== 'object') {
    return res.status(400).json({ ok: false, error: 'Invalid request.' });
  }

  const ip = String((req.headers['x-forwarded-for'] || '').split(',')[0] || req.socket?.remoteAddress || 'unknown').trim();
  const d = clean(body);

  // Bots fill the hidden field or submit instantly. Pretend success, send nothing.
  if (d.honeypot || (d.elapsed && d.elapsed < 2500)) {
    return res.status(200).json({ ok: true });
  }

  if (limited(ip)) {
    return res.status(429).json({ ok: false, error: 'Too many messages from this connection. Please try again in a few minutes.' });
  }

  const problem = validate(d);
  if (problem) return res.status(400).json({ ok: false, error: problem });

  const send = provider();
  if (!send) {
    console.error('[contact] No email provider configured. Set RESEND_API_KEY or SMTP_HOST/SMTP_USER/SMTP_PASS.');
    return res.status(500).json({ ok: false, error: 'The form is not fully set up yet.' });
  }

  const meta = { ip, time: new Date().toISOString() };
  const mail = buildEmail(d, meta);

  try {
    await send({ to: TO, replyTo: d.email, ...mail });
  } catch (err) {
    console.error('[contact] Delivery failed:', err && err.message);
    return res.status(502).json({ ok: false, error: 'We could not deliver your message just now.' });
  }

  // Confirmation to the visitor is best effort and never fails the request.
  if (process.env.AUTO_REPLY !== 'false') {
    try {
      await send({ to: d.email, replyTo: TO, ...buildReceipt(d) });
    } catch (err) {
      console.error('[contact] Auto-reply failed:', err && err.message);
    }
  }

  return res.status(200).json({ ok: true });
};

module.exports._internals = { clean, validate, buildEmail };
