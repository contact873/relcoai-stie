(function () {
  'use strict';

  /* ---------- mobile menu ---------- */
  var btn = document.querySelector('.menu-btn');
  var nav = document.getElementById('site-nav');
  if (btn && nav) {
    btn.addEventListener('click', function () {
      var open = nav.classList.toggle('open');
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  }

  /* ---------- growth calculator ---------- */
  var calc = document.getElementById('calc');
  if (calc) {
    var ids = ['visitors', 'conv-now', 'value', 'conv-target'];
    var el = {};
    ids.forEach(function (id) { el[id] = document.getElementById(id); });
    var fmtInt = new Intl.NumberFormat('en-US');
    var money = function (v) {
      if (v >= 1e6) return '$' + (v / 1e6).toFixed(2).replace(/0$/, '') + 'M';
      if (v >= 1e3) return '$' + fmtInt.format(Math.round(v / 1e3)) + 'k';
      return '$' + fmtInt.format(Math.round(v));
    };
    var update = function () {
      var visitors = +el.visitors.value;
      var now = +el['conv-now'].value / 100;
      var target = +el['conv-target'].value / 100;
      var value = +el.value.value;
      if (target < now) { target = now; }
      var leadsNow = visitors * now;
      var leadsTarget = visitors * target;
      var extra = leadsTarget - leadsNow;
      var annual = extra * value * 12;
      document.getElementById('o-visitors').textContent = fmtInt.format(visitors);
      document.getElementById('o-conv-now').textContent = (+el['conv-now'].value).toFixed(1) + '%';
      document.getElementById('o-value').textContent = '$' + fmtInt.format(value);
      document.getElementById('o-conv-target').textContent = (+el['conv-target'].value).toFixed(1) + '%';
      document.getElementById('r-now').textContent = fmtInt.format(Math.round(leadsNow));
      document.getElementById('r-target').textContent = fmtInt.format(Math.round(leadsTarget));
      document.getElementById('r-extra').textContent = '+' + fmtInt.format(Math.round(extra));
      document.getElementById('r-annual').textContent = '+' + money(annual);
    };
    ids.forEach(function (id) { el[id].addEventListener('input', update); });
    update();
  }

  /* ---------- contact form ---------- */
  var form = document.getElementById('contact-form');
  if (!form) return;

  var status = document.getElementById('form-status');
  var submit = document.getElementById('submit-btn');
  var started = Date.now();
  var params = new URLSearchParams(location.search);
  var topic = params.get('topic');
  var topicSel = document.getElementById('topic');
  if (topic && topicSel) {
    for (var i = 0; i < topicSel.options.length; i++) {
      if (topicSel.options[i].value === topic) { topicSel.selectedIndex = i; break; }
    }
  }
  var svc = params.get('service');
  var svcSel = document.getElementById('service');
  if (svc && svcSel) {
    for (var j = 0; j < svcSel.options.length; j++) {
      if (svcSel.options[j].value === svc) { svcSel.selectedIndex = j; break; }
    }
  }

  function setError(field, msg) {
    var box = document.getElementById('err-' + field.id);
    if (msg) {
      field.setAttribute('aria-invalid', 'true');
      if (box) box.textContent = msg;
    } else {
      field.removeAttribute('aria-invalid');
      if (box) box.textContent = '';
    }
  }

  function validate() {
    var ok = true, firstBad = null;
    var name = form.elements.name, email = form.elements.email, message = form.elements.message, consent = form.elements.consent;
    var rules = [
      [name, name.value.trim().length >= 2, 'Enter your name.'],
      [email, /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.value.trim()), 'Enter a valid email address so we can reply.'],
      [message, message.value.trim().length >= 10, 'Tell us a little more (at least 10 characters).'],
      [consent, consent.checked, 'Please tick the box so we may reply to you.']
    ];
    rules.forEach(function (r) {
      setError(r[0], r[1] ? '' : r[2]);
      if (!r[1]) { ok = false; if (!firstBad) firstBad = r[0]; }
    });
    if (firstBad) firstBad.focus();
    return ok;
  }

  function show(kind, html) {
    status.hidden = false;
    status.className = 'status ' + kind;
    status.innerHTML = html;
    status.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    status.hidden = true;
    if (!validate()) return;

    var data = {
      name: form.elements.name.value.trim(),
      email: form.elements.email.value.trim(),
      company: form.elements.company.value.trim(),
      phone: form.elements.phone.value.trim(),
      topic: form.elements.topic.value,
      service: form.elements.service.value,
      budget: form.elements.budget.value,
      website: form.elements.website.value,       // honeypot (label is "Leave this empty")
      site_url: form.elements.site_url.value.trim(),
      message: form.elements.message.value.trim(),
      elapsed: Date.now() - started,
      page: location.href
    };

    submit.disabled = true;
    var label = submit.textContent;
    submit.textContent = 'Sending...';

    fetch('/api/contact', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    })
      .then(function (res) {
        return res.json().catch(function () { return {}; }).then(function (body) { return { ok: res.ok, body: body }; });
      })
      .then(function (r) {
        if (r.ok && r.body.ok) {
          form.reset();
          started = Date.now();
          show('ok', '<strong>Message sent.</strong> A person will reply to ' + escapeHtml(data.email) + ' within one working day.');
        } else {
          var msg = (r.body && r.body.error) || 'Something went wrong on our side.';
          show('bad', '<strong>Your message was not sent.</strong> ' + escapeHtml(msg) +
            ' You can email <a href="mailto:contact@raschident.com">contact@raschident.com</a> or message us on <a href="https://wa.me/923237989871">WhatsApp</a>.');
        }
      })
      .catch(function () {
        show('bad', '<strong>Your message was not sent.</strong> Check your connection and try again, or email ' +
          '<a href="mailto:contact@raschident.com">contact@raschident.com</a> or use <a href="https://wa.me/923237989871">WhatsApp</a>.');
      })
      .then(function () {
        submit.disabled = false;
        submit.textContent = label;
      });
  });

  form.addEventListener('input', function (e) {
    if (e.target.getAttribute && e.target.getAttribute('aria-invalid')) setError(e.target, '');
  });

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
})();
